package com.example.appproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class loginpage extends AppCompatActivity {
    EditText e1,e2;
    Button b1;
    DatabaseCollect db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);
        db=new DatabaseCollect(this);
        e1=(EditText)findViewById(R.id.em1);
        e2=(EditText)findViewById(R.id.p1);
        b1= (Button)findViewById(R.id.b2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email= e1.getText().toString();
                String password= e2.getText().toString();
                Boolean chkemailpass=db.ep(email,password);
                if(chkemailpass==true){
                    Intent i= new Intent(loginpage.this,Main2Activity.class);
                    startActivity(i);
                }
                else{
                    Toast.makeText(getApplicationContext(),"Wrong email or password",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
