package com.example.appproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        final Random myRandom = new Random();

        Button buttonGenerate = (Button) findViewById(R.id.generate);
        final TextView textGenerateNumber = (TextView) findViewById(R.id.generatenumber);


        buttonGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textGenerateNumber.setText(String.valueOf(myRandom.nextInt(100000)));

            }
        });

    }
}
